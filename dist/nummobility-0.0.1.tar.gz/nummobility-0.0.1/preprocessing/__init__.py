"""
    The preprocessing package contains several modules for preprocessing of data.
"""
